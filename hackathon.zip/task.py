def change(one,*two):
    print(type(two))
change(1,2,3,4)